package com.imchobo.sayren_back.domain.notification;

import lombok.RequiredArgsConstructor;
import lombok.extern.log4j.Log4j2;
import org.springframework.boot.test.context.SpringBootTest;

@Log4j2
@RequiredArgsConstructor
@SpringBootTest
public class NotificationTest {
}

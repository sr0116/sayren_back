package com.imchobo.sayren_back.domain.common.en;

public enum CommonStatus {
  ACTIVE, DISABLED, DELETED
}

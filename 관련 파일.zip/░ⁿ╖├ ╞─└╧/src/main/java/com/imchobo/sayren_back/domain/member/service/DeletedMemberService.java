package com.imchobo.sayren_back.domain.member.service;

import com.imchobo.sayren_back.domain.member.entity.Member;

public interface DeletedMemberService {
  void deleteMember(Member member);
  void emailVaildate(String email);
}

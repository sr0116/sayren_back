package com.imchobo.sayren_back.domain.product.recode;

import com.imchobo.sayren_back.domain.product.entity.Product;

import java.util.List;

public record Products(List<Product> products) {
}

package com.imchobo.sayren_back.domain.board.en;

public enum CategoryType {
  PRODUCT, REVIEW, QNA, NOTICE, FAQ
}

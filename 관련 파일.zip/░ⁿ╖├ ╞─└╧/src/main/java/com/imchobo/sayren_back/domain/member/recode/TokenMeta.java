package com.imchobo.sayren_back.domain.member.recode;

public record TokenMeta(Long memberId, long ttlMillis) {
}

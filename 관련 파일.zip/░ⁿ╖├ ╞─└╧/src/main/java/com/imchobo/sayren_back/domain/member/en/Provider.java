package com.imchobo.sayren_back.domain.member.en;

public enum Provider {
  GOOGLE, KAKAO, NAVER
}

package com.imchobo.sayren_back.domain.term.en;

public enum TermStatus {
  ACTIVE, DISABLED
}

package com.imchobo.sayren_back.domain.member.service;

import com.imchobo.sayren_back.domain.member.dto.*;
import com.imchobo.sayren_back.domain.member.recode.AccessToken;
import com.imchobo.sayren_back.domain.member.recode.SocialUser;
import com.imchobo.sayren_back.security.dto.MemberAuthDTO;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.springframework.http.ResponseEntity;

public interface AuthService {
  MemberLoginResponseDTO login(MemberLoginRequestDTO memberLoginRequestDTO, HttpServletResponse response, HttpServletRequest request);
  MemberLoginResponseDTO getUser();
  void logout(HttpServletResponse response, String refreshToken);
  AccessToken accessToken(HttpServletResponse response, String refreshToken);
  MemberLoginResponseDTO socialSignup(SocialSignupRequestDTO socialSignupRequestDTO, HttpServletResponse response, HttpServletRequest request);
  MemberLoginResponseDTO socialLink(SocialLinkRequestDTO socialLinkRequestDTO, HttpServletResponse response, HttpServletRequest request);
  String socialLinkRedirectUrl(String provider);
  void hasResetPasswordKey(String token);
}

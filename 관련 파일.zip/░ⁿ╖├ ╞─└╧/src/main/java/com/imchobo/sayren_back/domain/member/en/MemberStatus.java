package com.imchobo.sayren_back.domain.member.en;

public enum MemberStatus {
  READY, ACTIVE, DISABLED, DELETED
}

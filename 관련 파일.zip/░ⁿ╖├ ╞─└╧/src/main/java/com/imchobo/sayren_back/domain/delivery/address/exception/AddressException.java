package com.imchobo.sayren_back.domain.delivery.address.exception;

public class AddressException {
}

package com.imchobo.sayren_back.domain.member.service;

import com.imchobo.sayren_back.domain.member.entity.Member;

public interface MemberTermService {
  void saveTerm(Member member);
}

package com.imchobo.sayren_back.domain.order.en;

public enum OrderPlanType {
  PURCHASE, RENTAL

  //구매, 렌탈
}

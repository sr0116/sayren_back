package com.imchobo.sayren_back.domain.notification.en;

public enum NotificationStatus {
  UNREAD, READ
}

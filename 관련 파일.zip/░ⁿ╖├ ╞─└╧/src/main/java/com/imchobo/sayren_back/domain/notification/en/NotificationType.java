package com.imchobo.sayren_back.domain.notification.en;

public enum NotificationType {
  ORDER, PAYMENT,  SUBSCRIBE, SUBSCRIBE_ROUND , DELIVERY

}

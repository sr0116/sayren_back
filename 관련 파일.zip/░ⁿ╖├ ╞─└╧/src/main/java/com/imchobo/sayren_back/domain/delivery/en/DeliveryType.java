package com.imchobo.sayren_back.domain.delivery.en;

public enum DeliveryType {
  DELIVERY, RETURN
  //배송,반품
}

package com.imchobo.sayren_back.domain.order.OrderPlan.exception;

public class OrderPlanException {
}

package com.imchobo.sayren_back.domain.member.en;

public enum Role {
  USER, ADMIN
}

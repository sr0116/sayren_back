package com.imchobo.sayren_back.domain.common.en;

import lombok.Getter;

@Getter
public enum ActorType {
SYSTEM, USER, ADMIN
}
